import Realm from 'realm';
export const TODOLIST_SCHEMA = 'TodoList';
export const TODO_SCHEMA = 'Todo';
export const TodoChema = {
  name: TODO_SCHEMA,
  primaryKey: 'id',
  properties: {
    id: 'int',
    name: {type: 'string', indexed: true},
    done: {type: 'bool', default: false},
  },
};
export const TodoListSchema = {
  name: TODOLIST_SCHEMA,
  primaryKey: 'id',
  properties: {
    id: 'int',
    name: 'string',
    creationDate: 'date',
    todos: {type: 'list', objectType: TODO_SCHEMA},
  },
};
const databaseOptions = {
    path: 'todoListApp.realm',
    schema: [TodoListSchema, TodoChema],
    schemaVersion: 0,
}
export const insertNewTodoList = (newTodoList) => Promise((resolve, reject)=>{
    Realm.open(databaseOptions).then(realm=>{
        realm.write(()=>{
            realm.create(TODOLIST_SCHEMA, newTodoList);
            resolve(newTodoList);
        });
    }).catch((error) => reject(error));
});
export const updateTodoList = todoList => new Promise((resolve, reject)=>{
    Realm.open(databaseOptions).then(realm =>{
        realm.write(() => {
            let updatingTodoList = realm.objectForPrimaryKey(TODOLIST_SCHEMA,todoList.id);
            updatingTodoList.name = todoList.name;
            resolve();
        });
    }).catch((error) => reject(error));;
});
export const deleteTodoList = todoListId => new Promise((resolve, reject)=>{
    realm.open(databaseOptions).then(realm =>{
        realm.write(()=>{
            let deletingTodoList = realm.objectForPrimaryKey(TODOLIST_SCHEMA, todoList.id);
            realm.delete(deletingTodoList);
            resolve();
        });
    }).catch((error) =>reject(error));;
});
export const deleteAllTodoList = todoListId => new Promise((resolve, reject)=>{
    realm.open(databaseOptions).then(realm =>{
        realm.write(()=>{
            let allTodoLists = realm.objects(TODOLIST_SCHEMA);
            realm.delete(allTodoLists);
            resolve();
        });
    }).catch((error) =>reject(error));;
});
export default new Realm(databaseOptions);